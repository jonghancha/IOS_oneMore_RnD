//
//  LiftingViewController.swift
//  onemoretimer
//
//  Created by 고종찬 on 2021/02/19.
//

import UIKit

class LiftingViewController: UIViewController {

    @IBOutlet weak var LiftingUiView: UIView!
    @IBOutlet weak var buttonTimeCount: UIButton!
    @IBOutlet weak var buttontimeSelect: UIButton!
    @IBOutlet weak var buttonStart: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        LiftingUiView.layer.masksToBounds = true // 레이아웃 설정 가능 (true 설정안해주면 round 설정 불가능)
        LiftingUiView.layer.cornerRadius = 20 // 라운드 설정값
        
        buttonTimeCount.layer.masksToBounds = true
        buttonTimeCount.layer.cornerRadius = 20
        buttontimeSelect.layer.masksToBounds = true
        buttontimeSelect.layer.cornerRadius = 20
        buttonStart.layer.masksToBounds = true
        buttonStart.layer.cornerRadius = 20
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
