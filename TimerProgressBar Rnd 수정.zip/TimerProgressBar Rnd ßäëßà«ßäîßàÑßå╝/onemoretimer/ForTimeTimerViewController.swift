//
//  ForTimeTimerViewController.swift
//  onemoretimer
//
//  Created by 정정이 on 2021/02/20.
//

import UIKit

class ForTimeTimerViewController: UIViewController {
    
    
    @IBOutlet weak var forTimeTimerUIView: UIView!
    @IBOutlet weak var buttonTabCount: UIButton!
    @IBOutlet weak var forTimeProgressBarUIView: UIView!
    @IBOutlet weak var buttonTabProgressBar: UIButton!
    @IBOutlet weak var labelTimer: UILabel!
 
    
    
    // segue를 통해 받아온 분
    var getTime: String = ""
    

    
    // 프로그래스바 //
    var forTimeProgressBar = ForTimeProgressBar()
    var radius: CGFloat!
    var progress: CGFloat!
    var answeredCorrect = 0
    var totalQuestions = 0
    
    
    
    // 타이머 //
    let countUpSelector: Selector = #selector(ForTimeTimerViewController.updateTime)
    let countDownSelector: Selector = #selector(ForTimeTimerViewController.countDownTime)
    static var timeOut = 0 // 시간 얼마나 가는지는 이 변수로 설정.
    let interval = 1.0// 시간 interval  1초
    var countUpTimer = Timer()
    var countDownTimer = Timer()
    var countDown = 10
    var countUp = 0 // 총 TIMER COUNT
    var minute = 0 // TIMER 분
    var second = 0 // TIMER 초
    var minuteText = ""
    var secondText = ""
    
    // button status //
    var countDownButtonStatus = true // 처음에는 카운트다운버튼 활성화
    var countUpButtonStatus = false // 처음에는 카운트업버튼 비활성화
    var countUpButtonOnOff = true // true 일때가 restart, false 일때가 pause
    let orangeColor = #colorLiteral(red: 1, green: 0.5215686275, blue: 0.2039215686, alpha: 1)                  // true 일때 누르면 false 로 바뀌면서 pause
    
    
    // 탭 카운트
    var tabCount = 0 // 초기값 설정
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        ForTimeTimerViewController.timeOut = Int(getTime)! * 60 // timeOut 변수에 segue로 가져온 값 Int변환 및 초로 변환
    
        
        // Do any additional setup after loading the view.

        
        forTimeTimerUIView.layer.masksToBounds = true
        forTimeTimerUIView.layer.cornerRadius = 20
        buttonTabCount.layer.masksToBounds = true
        buttonTabCount.layer.cornerRadius = 20
        
        buttonTabCount.setTitle("COUNT : \(tabCount)", for: .normal)
        buttonTabCount.isEnabled = false
        buttonTabCount.backgroundColor = UIColor.gray
        
    }
    
    
    // tab count button 클릭시 +1씩증가
    @IBAction func buttonTabCount(_ sender: UIButton) {
        
  
        tabCount += 1 // tab 할때마다 1씩 증가
        buttonTabCount.setTitle("COUNT : \(tabCount)", for: .normal)
        
    }
    
    @IBAction func buttonTabProgressBar(_ sender: UIButton) {
        
        if countUpButtonStatus{
            // 카운트 업일때 버튼 ACTION
            // TRUE 일때 누르면 STOP
            if countUpButtonOnOff{
                progressCirclePause(nowTime: Double(countUp))
                countUpTimer.invalidate()
                labelTimer.text = "pause"
                countUpButtonOnOff = false
                // 탭버튼 비활성화
                buttonTabCount.isEnabled = false
                buttonTabCount.backgroundColor = UIColor.gray
                
            // FALSE 일때 누르면 RESTART
            }else{
                labelTimer.text = "\(minuteText):\(secondText)"
                progressCircleRestart(nowTime: Double(countUp))
                countUpTimer = Timer.scheduledTimer(timeInterval: interval, target: self, selector: countUpSelector, userInfo: nil, repeats: true)
                countUpButtonOnOff = true
                //탭버튼 활성화
                buttonTabCount.backgroundColor = orangeColor
                buttonTabCount.isEnabled = true
            }
           
            
        }else{
            // 카운트 다운일때 버튼 ACTION
            // 카운트다운 START
            if countDownButtonStatus{
                labelTimer.text = "\(countDown)"
                countDownTimer = Timer.scheduledTimer(timeInterval: interval, target: self, selector: countDownSelector, userInfo: nil, repeats: true)
                countDownButtonStatus = false
                
                //카운트다운 PAUSE
            }else{
                labelTimer.text = "Pause"
                countDownButtonStatus = true
                countDownTimer.invalidate()
            }
        }
    }
    

    
  // segue 연결
    func receiveItem(_ time: String) {
        getTime = time
    }
    
    
    
    // COUNTDOWN
    @objc  func countDownTime(){
        labelTimer.text = "\(countDown)"
        countDown -= 1
        if countDown == -1{
            countDownTimer.invalidate()
            countUpButtonStatus = true
            labelTimer.text = "GO"
            countUpTimer = Timer.scheduledTimer(timeInterval: interval, target: self, selector: countUpSelector, userInfo: nil, repeats: true)
        }
    }

    
    
    
    
    // COUNTUP
    @objc func updateTime(){
        if countUp == 0{
            progressCircle()
            buttonTabCount.backgroundColor = orangeColor
            buttonTabCount.isEnabled = true

        }else{
            
        }
        
        countUp += 1
        second += 1
        
        if second == 60 {
            minute += 1
            second = 0
        }
        
        if minute < 10{
            minuteText = "0\(minute)" // 분이 10보다 작으면 앞에 0을 붙여주므로 01:00을 완성
        }else{
            minuteText = "\(minute)"
        }
        if second < 10{
            secondText = "0\(second)"
        }else{
            secondText = "\(second)"
        }
        
        labelTimer.text = "\(minuteText):\(secondText)"
        
        if countUp == ForTimeTimerViewController.timeOut{
            countUpTimer.invalidate()
            buttonTabProgressBar.isEnabled = false
            labelTimer.text = "END"
            buttonTabCount.isEnabled = false
            buttonTabCount.backgroundColor = UIColor.gray
            
        }
        
        

    }
    
    
    
    
    
    
    //처음 시작 프로그래스바 (기본)
    func progressCircle() {
        answeredCorrect = 100
        totalQuestions = 100

        //Configure Progress Bar
        radius = (forTimeProgressBarUIView.frame.height)/2.60
        progress = CGFloat(answeredCorrect) / CGFloat (totalQuestions)
        forTimeProgressBar.addProgressBar(radius: radius, progress: progress)
        forTimeProgressBar.center = forTimeProgressBarUIView.center

        //Adding view
        forTimeProgressBarUIView.addSubview(forTimeProgressBar)
        forTimeProgressBar.loadProgress(percentage: progress)
    }
    
    
    
   


    // 프로그래스바 일시정지
    func progressCirclePause(nowTime: Double) {
        answeredCorrect = 100
        totalQuestions = 100

        //Configure Progress Bar
        radius = (forTimeProgressBarUIView.frame.height)/2.60
        progress = CGFloat(answeredCorrect) / CGFloat (totalQuestions)
        forTimeProgressBar.addProgressBar(radius: radius, progress: progress)
        forTimeProgressBar.center = forTimeProgressBarUIView.center


        //Adding view
        forTimeProgressBarUIView.addSubview(forTimeProgressBar)
        forTimeProgressBar.loadProgressPause(percentage: progress,nowTime: nowTime)
    }

    
    
    // 프로그래스바 재시작
    func progressCircleRestart(nowTime: Double) {
        answeredCorrect = 100
        totalQuestions = 100

        //Configure Progress Bar
        radius = (forTimeProgressBarUIView.frame.height)/2.60
        progress = CGFloat(answeredCorrect) / CGFloat (totalQuestions)
        forTimeProgressBar.addProgressBar(radius: radius, progress: progress)
        forTimeProgressBar.center = forTimeProgressBarUIView.center

        //Adding view
        forTimeProgressBarUIView.addSubview(forTimeProgressBar)

        forTimeProgressBar.loadProgressRestart(percentage: progress, nowTime: nowTime)
    }
      
    
    
}//-----
