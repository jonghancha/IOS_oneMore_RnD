//
//  ForTimeViewController.swift
//  onemoretimer
//
//  Created by 정정이 on 2021/02/19.
//

import UIKit
import SimpleAlertPickers // <--- SimpleAlertPickers 추가

class ForTimeViewController: UIViewController {

    @IBOutlet weak var forTimeUIView: UIView!
    @IBOutlet weak var buttonForTimeStart: UIButton!
  
    @IBOutlet weak var labelCountTimeValue: UILabel!
    @IBOutlet weak var labelSelectTimeValue: UILabel!
    @IBOutlet weak var buttonRoundCount: UIButton!
    @IBOutlet weak var buttonSelectTime: UIButton!
    @IBOutlet weak var labelFirstValue: UILabel!
    @IBOutlet weak var labelSecondValue: UILabel!
    @IBOutlet weak var labelThirdValue: UILabel!
    
    
    
    var countTimeValue: String? // 피커뷰로 라운드값 받는 변수
    var selecteTimeValue: String? // 피커뷰로 받는 분 값 받는 변수
    
    
    // 피커에 들어갈 배열 구성.
    var times = [String]()  //= (5...100).map { String($0) }
    var count = [String]() //= (1...10).map { String($0) }
    
    
    var buttonTimes = [String]()
    var buttonCount = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 버튼 코너라운드 설정
        forTimeUIView.layer.masksToBounds = true // 레이아웃 설정 가능 (true 설정안해주면 round 설정 불가능)
        forTimeUIView.layer.cornerRadius = 20 // 라운드 설정값
        buttonForTimeStart.layer.masksToBounds = true
        buttonForTimeStart.layer.cornerRadius = 20
        buttonRoundCount.layer.masksToBounds = true
        buttonRoundCount.layer.cornerRadius = 20
        buttonSelectTime.layer.masksToBounds = true
        buttonSelectTime.layer.cornerRadius = 20
        
        
        // Do any additional setup after loading the view.
        
        // 텍스트컬러 커스텀
        let orangeColor = #colorLiteral(red: 1, green: 0.5215686275, blue: 0.2039215686, alpha: 1)
        
        // 텍스트컬러 바꾸기 (포인트컬러)
        labelCountTimeValue.textColor = orangeColor
        labelSelectTimeValue.textColor = orangeColor
        
        // 피커퓨로 받은 값 넣어주기
        labelCountTimeValue.text = "\(String(describing: countTimeValue))"
        labelSelectTimeValue.text = "\(String(describing: selecteTimeValue))"
        

        
        // 5 ~ 100 분 1분 단위
                for i in 5...100{
                    if i < 10{
                        times.append("0\(i):00 분")
                    }else{
                        times.append("\(i):00 분")

                    }
                    buttonTimes.append("\(i)")
                }
        
        
        // 1 ~ 10 회 라운드
                for i in 1...10{
                        count.append("\(i)회")
                        buttonCount.append("\(i)")
                    }
                   


                
        // 뷰가 생성될때 피커와 버튼에 값 주기
        selecteTimeValue = times[0]
        countTimeValue = count[0]
    }
    
    // 라운드 버튼 클릭시 이벤트
    @IBAction func buttonRoundCount(_ sender: UIButton) {
        // Alert 형식
        let alert = UIAlertController( title: "몇 라운드 할까요?", message: nil, preferredStyle: UIAlertController.Style.alert)
        
        
        // addPickerView에 매개변수로 있는 values 자체가 [[String]] 형식이라 맞춰서 써야 될거같습니다.
        let pickerViewValues: [[String]] = [count]
        let pickerViewSelectedValue: PickerViewViewController.Index = (column: 0, row: count.firstIndex(of: countTimeValue!) ?? 0) // picker가 생성될 때 pickedValue가 선택된 상태로 alert가 뜸.
        // alert에 picker 추가해주기 + async를 통해 버튼의 text 바꿔줌.
        // picker 선택시 action은 이 안에 써주시면 됩니다.
        alert.addPickerView(values: pickerViewValues, initialSelection: pickerViewSelectedValue) { vc, picker, index, values in
            DispatchQueue.main.async {
                UIView.animate(withDuration: 1) {
                    self.countTimeValue = self.buttonCount[index.row] // 피커에서 선택한 값 변수에 저장해주기.
                    self.buttonRoundCount.setTitle(self.countTimeValue! + "회", for: .normal)
                    self.labelCountTimeValue.text = self.countTimeValue! + "회"
                    
                    // 2개의 버튼 선택이 nil이 아닐경우 isHidden false 하나라도 선택이 안되면 isHidden true
                    if self.labelSelectTimeValue.text != "nil" && self.labelCountTimeValue.text != "nil" {
                        self.labelSelectTimeValue.isHidden = false
                        self.labelCountTimeValue.isHidden = false
                        self.labelFirstValue.isHidden = false
                        self.labelSecondValue.isHidden = false
                        self.labelThirdValue.isHidden = false
                    }
                    
                }
            }
        }
        
        
        alert.addAction(title: "완료", style: .cancel)
        alert.show()
        
        
        
    }
    
    // selectButton 클릭 이벤트
    @IBAction func buttonSelectTime(_ sender: UIButton) {
        // Alert 형식
        let alert = UIAlertController( title: "얼마나 할까요?", message: nil, preferredStyle: UIAlertController.Style.alert)
        
        // addPickerView에 매개변수로 있는 values 자체가 [[String]] 형식이라 맞춰서 써야 될거같습니다.
        let pickerViewValues: [[String]] = [times]
        let pickerViewSelectedValue: PickerViewViewController.Index = (column: 0, row: times.firstIndex(of: selecteTimeValue!) ?? 0) // picker가 생성될 때 pickedValue가 선택된 상태로 alert가 뜸.

        // alert에 picker 추가해주기 + async를 통해 버튼의 text 바꿔줌.
        // picker 선택시 action은 이 안에 써주시면 됩니다.
        alert.addPickerView(values: pickerViewValues, initialSelection: pickerViewSelectedValue) { vc, picker, index, values in
            DispatchQueue.main.async {
                UIView.animate(withDuration: 1) {
                    self.selecteTimeValue = self.buttonTimes[index.row] // 피커에서 선택한 값 변수에 저장해주기.
                    self.buttonSelectTime.setTitle(self.selecteTimeValue! + "분", for: .normal)
                    self.labelSelectTimeValue.text = self.selecteTimeValue! + "분"
                    
                    if self.labelSelectTimeValue.text != "nil" && self.labelCountTimeValue.text != "nil" {
                        self.labelSelectTimeValue.isHidden = false
                        self.labelCountTimeValue.isHidden = false
                        self.labelFirstValue.isHidden = false
                        self.labelSecondValue.isHidden = false
                        self.labelThirdValue.isHidden = false
                    }
                }
            }
        }
        
        
        alert.addAction(title: "완료", style: .cancel)
        alert.show()
        
       
        
    }
    
    
    
    
    
  
    
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "forTimeSegue"{
            let timerView = segue.destination as! ForTimeTimerViewController
            timerView.receiveItem(selecteTimeValue!)
            
        }
        
        
    }
    
}
